<?php switch($type):
    case ('actions'): ?>
        <?php if(auth()->user()->hasPermission('edit_role')): ?>
            <a class="btn btn-sm btn-primary" href="<?php echo e(route('dashboard.roles.edit',$data->id)); ?>"><i class="fa fa-pen"></i></a>
        <?php endif; ?>

        <?php if(auth()->user()->hasPermission('show_permissions')): ?>
            <a class="btn btn-sm btn-warning" href="<?php echo e(route('dashboard.permissions.edit',$data->id)); ?>"><i class="fa fa-eye"></i></a>        
        <?php endif; ?>
        <?php break; ?>

    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/roles/actions.blade.php ENDPATH**/ ?>