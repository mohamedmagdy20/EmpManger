

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="page-title"> <?php echo app('translator')->get('lang.change-password'); ?></h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('dashboard.users.profile.index')); ?>"><?php echo app('translator')->get('lang.profile'); ?></a></li>
      </ol>
    </nav>
    
  </div>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <form class="forms-sample" method="POST" action="<?php echo e(route('dashboard.users.profile.change-password')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.old_password'); ?></label>
                            <input type="password" class="form-control" name="old_password" id="exampleInputPassword4"  value="<?php echo e(old('password')); ?>" placeholder="Password">
                          </div>
                          <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"> <?php echo e($message); ?> </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.password'); ?></label>
                            <input type="password" class="form-control" name="password" id="exampleInputPassword4"  value="<?php echo e(old('password')); ?>" placeholder="Password">
                          </div>
                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"> <?php echo e($message); ?> </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.confirm_password'); ?></label>
                            <input type="password" class="form-control" name="password_confirmation" id="exampleInputPassword4"  value="<?php echo e(old('password_conformation')); ?>" placeholder="Password">
                          </div>
                    </div>

                </div>
              
            
            
              <button type="submit" class="btn btn-primary mr-2"><?php echo app('translator')->get('lang.submit'); ?></button>
              <a href="<?php echo e(route('dashboard.users.profile.index')); ?>" class="btn btn-light"><?php echo app('translator')->get('lang.cencel'); ?></a>
            </form>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/profile/change.blade.php ENDPATH**/ ?>