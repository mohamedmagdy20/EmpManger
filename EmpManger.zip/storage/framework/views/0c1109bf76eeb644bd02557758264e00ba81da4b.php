

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="page-title"> <?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.users'); ?></h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('dashboard.users.index')); ?>"><?php echo app('translator')->get('lang.users'); ?></a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('dashboard.users.create')); ?>"><?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.users'); ?></a></li>
      </ol>
    </nav>
    
  </div>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title"><?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.users'); ?></h4>
            <form class="forms-sample" method="POST" action="<?php echo e(route('dashboard.users.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputName1"><?php echo app('translator')->get('lang.name'); ?></label>
                            <input type="text" class="form-control" name="name" id="exampleInputName1" value="<?php echo e(old('name')); ?>" placeholder="Name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail3"><?php echo app('translator')->get('lang.email'); ?></label>
                            <input type="email" class="form-control" name="email" id="exampleInputEmail3"  value="<?php echo e(old('email')); ?>" placeholder="Email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.password'); ?></label>
                            <input type="password" class="form-control" name="password" id="exampleInputPassword4"  value="<?php echo e(old('password')); ?>" placeholder="Password">
                          </div>
                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"> <?php echo e($message); ?> </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.confirm_password'); ?></label>
                            <input type="password" class="form-control" name="password_confirmation" id="exampleInputPassword4"  value="<?php echo e(old('password_conformation')); ?>" placeholder="Password">
                          </div>
                    </div>

                    <div class="col-md-6">
                        <label for="status"><?php echo app('translator')->get('lang.status'); ?></label>

                        <div class="form-group ml-5">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" name="status"   id="flexSwitchCheckChecked"  checked>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                       
                    </div>
                    <div class="col-md-12 mb-3">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('lang.image'); ?></label>
                            <input type="file" name="image" id="choose-file" class="form-control">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                           
                          </div>


                          <div id="img-preview"></div>
                
                    </div>


                    <div class="col-md-12">
                        <label for=""><?php echo app('translator')->get('lang.role'); ?></label>

                        <div class="form-group ml-5">

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="<?php echo e($d->name); ?>" name="role" id="<?php echo e($d->name); ?>">
                                        <label class="form-check-label" for="<?php echo e($d->name); ?>">
                                         <?php echo e($d->display_name); ?>

                                        </label>
                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
              
            
            
              <button type="submit" class="btn btn-primary mr-2"><?php echo app('translator')->get('lang.submit'); ?></button>
              <a href="<?php echo e(route('dashboard.users.index')); ?>" class="btn btn-light"><?php echo app('translator')->get('lang.cencel'); ?></a>
            </form>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/users/create.blade.php ENDPATH**/ ?>