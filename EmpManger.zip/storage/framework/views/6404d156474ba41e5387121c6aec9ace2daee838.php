
<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="container-fluid">
    
    <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
    
                <h4 class="card-title"><?php echo app('translator')->get('lang.edit'); ?> <?php echo app('translator')->get('lang.permissions'); ?>  <?php echo e($role->display_name); ?></h4>
                
                <form method="post" action="<?php echo e(route('dashboard.permissions.update',$role->id)); ?>"  class="needs-validation"  novalidate >
                    <?php echo csrf_field(); ?>
    
                <div class="row mb-3 ml-4">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 bg-white">
                        <div class="">
                            <div class="checkbox checkbox-primary mb-2 ">
                                <input id="<?php echo e($permission->id); ?>" type="checkbox"
                                    <?php echo e($role->hasPermission($permission->name) ? 'checked' : ''); ?>

                                    value="<?php echo e($permission->id); ?>" name="permissions[]" class="form-check-input" >
                                <label for="<?php echo e($permission->id); ?>" style="padding-right: 20px"><?php echo e(App::isLocale('ar') ? $permission->description :  $permission->display_name); ?></label>
                            </div>
                        </div>
                    </div> <!-- end col-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
    
                
                <!-- end row -->
    
                 <input type="submit" class="btn btn-primary " value="<?php echo app('translator')->get('lang.submit'); ?>">
                 <a href="<?php echo e(route('dashboard.roles.index')); ?>" class="btn btn-light"><?php echo app('translator')->get('lang.cencel'); ?></a>
                </form>
                 
               
               
            </div>
        </div>
    </div> <!-- end col -->
    </div>
     
    
    
    </div>
    </div>
    
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/permissions/index.blade.php ENDPATH**/ ?>