

<?php $__env->startSection('content'); ?>

<div class="page-header">
  <h3 class="page-title"><?php echo app('translator')->get('lang.employees'); ?> <?php echo app('translator')->get('lang.requests'); ?></h3>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
      <li class="breadcrumb-item active"><a href="<?php echo e(route('dashboard.users.index')); ?>"><?php echo app('translator')->get('lang.requests'); ?></a></li>
   
    </ol>
  </nav>
  
</div>
<div class="col-md-12 grid-margin stretch-card">

<div class="card">
    <div class="card-body">
   
    <div class="row justify-content-between align-items-center">

        <div class="col-md-4">
            <div class="form-group">
                <label for="employee_id"><?php echo app('translator')->get('lang.employees'); ?></label>
                <select name="employee_id" class="form-select" id="employee_id">
                    <option value=""><?php echo app('translator')->get('lang.employees'); ?></option>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
          
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="type"><?php echo app('translator')->get('lang.type'); ?></label>
                <select name="type" class="form-select" id="type">
                    <option value="new"><?php echo app('translator')->get('lang.new'); ?></option>
                    <option value="rl"><?php echo app('translator')->get('lang.rl'); ?></option>
                    <option value="da"><?php echo app('translator')->get('lang.da'); ?></option>
                    <option value="renewal"><?php echo app('translator')->get('lang.renewal'); ?></option>
                </select>
            </div>
          
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <label for="status"><?php echo app('translator')->get('lang.status'); ?></label>
                <select name="status" class="form-select" id="status">
                    <option value="<?php echo e(old('status','1')); ?>"><?php echo app('translator')->get('lang.status'); ?></option>
                    <option value="<?php echo e(old('status','0')); ?>"><?php echo app('translator')->get('lang.deactive'); ?></option>
                </select>
            </div>
          
        </div>

        
        <div class="col-md-4">
            <div class="form-group">
                <label for="request_status"><?php echo app('translator')->get('lang.request_type'); ?></label>
                <select name="request_status" class="form-select" id="request_status">
                    <option value="new"><?php echo app('translator')->get('lang.new'); ?></option>
                    <option value="on_process"><?php echo app('translator')->get('lang.on_process'); ?></option>
                    <option value="finished"><?php echo app('translator')->get('lang.finished'); ?></option>
                </select>
            </div>
          
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="date_from"><?php echo app('translator')->get('lang.date_from'); ?></label>
                <input type="date" name="date_from" class="form-control" id="date_from">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="date_from"><?php echo app('translator')->get('lang.date_to'); ?></label>
                <input type="date" name="date_to" class="form-control" id="date_to">
            </div>
        </div>

        
        <div class="col-md-6 mt-4">
            <div class="d-flex">
                <div class="form-group ">
                    <button class="btn btn-primary" onclick="handleFilter()"><?php echo app('translator')->get('lang.search'); ?> <i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
                <div class="form-group ml-2">
                    <button class="btn " onclick="handleClear()"><?php echo app('translator')->get('lang.clear'); ?></button>
                </div>
            
            </div>
            
        </div>


    

    
    </div>
</div>
        
    </div>
</div>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row justify-content-between align-items-center">
          <div class="col-md-6">
            <h4 class="card-title"><?php echo app('translator')->get('lang.show'); ?> <?php echo app('translator')->get('lang.employees'); ?> <?php echo app('translator')->get('lang.requests'); ?></h4>
          </div>
          <?php if(auth()->user()->hasPermission('add_requests')): ?>
          <div class="col-md-6">
            <a href="<?php echo e(route('dashboard.requests.create')); ?>" class="btn btn-success"> <?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.requests'); ?> <i class="fa fa-plus" style="font-size: 15px;"></i></a>
          </div>
          <?php endif; ?>
        
        </div>

        
        <div class="table-responsive">
            <table class="table table-striped" id="employee-table">
                <thead>
                  <tr>
                    <th> <?php echo app('translator')->get('lang.employees'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.type'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.status'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.request_type'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.change'); ?> <?php echo app('translator')->get('lang.request_type'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.date'); ?></th>
                    <th> <?php echo app('translator')->get('lang.created_by'); ?></th>
                    <th> <?php echo app('translator')->get('lang.actions'); ?> </th>  
                  </tr>
                </thead>
                <tbody>

                </tbody>
              </table>
           
        </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script >

    let UsersTable = null
    
    function setUserDatatable() {
        var url = "<?php echo e(route('dashboard.requests.data')); ?>";
        
        UsersTable = $("#employee-table").DataTable({
            processing: true,
            serverSide: true,
            dom: 'Blfrtip',
            lengthMenu: [0, 5, 10, 20, 50, 100, 200, 500],
            pageLength: 9,
            sorting: [0, "DESC"],
            ordering: false,
            ajax: url,
            
            language: {
                paginate: {
                    "previous": "<i class='mdi mdi-chevron-left'>",
                    "next": "<i class='mdi mdi-chevron-right'>"
                },
            },
    
            
            columns: [
                {
                    data: 'employee_id'
                },
                {
                    data: 'type'
                },
                {
                    data: 'status'
                },
                {
                    data: 'request_status'
                },
                {
                  data:'change-status'
                },             
                {
                    data:'created_at'
                },
                {
                    data:'created_by'
                },
                {
                    data: 'actions'
                }
            ],
        });
    }
    
    setUserDatatable();
    
    
    function deleteConfirmation(id) {
            swal({
                title: "Delete?",
                text: "Please ensure and then confirm!",
                type: "warning",
                showCancelButton: !0,
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel!",
                reverseButtons: !0
            }).then(function (e) {
    
                if (e.value === true) {
                    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    
                    $.ajax({
                        type: 'GET',
                        url: "<?php echo e(url('dashboard/requests/delete')); ?>/" + id,
                        data: {_token: CSRF_TOKEN},
                        dataType: 'JSON',
                        success: function (results) {
    
                               
                                if(results.status == true)
                                {
                                    swal("Done!", results.message, "success");
                                    UsersTable.ajax.reload()
                               
                                }
                        },
                    });
    
                } else {
                    e.dismiss;
                }
    
            }, function (dismiss) {
                return false;
            })
        }

    function changeStatus(id,status)
    {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    
        $.ajax({
            type: 'GET',
            url: "<?php echo e(route('dashboard.requests.change-status')); ?>",
            data: {_token: CSRF_TOKEN,id:id,status:status},
            dataType: 'JSON',
            success: function (results) {                   
            if(results.status == true)
            {
                swal("Done!", results.message, "success");
                UsersTable.ajax.reload()
            
            }
            },
        });
  
    }

    function handleFilter() {
            employee_id = $('#employee_id').val() || '';
            type = $('#type').val() || '';
            status = $('#status').val() || '';
            
            request_status = $('#request_status').val() || '';
            date_from = $('#date_from').val() || '';
            date_to = $('#date_to').val() || '';
       
            if (UsersTable) {
                var url = "<?php echo e(route('dashboard.requests.data')); ?>" + `?employee_id=${employee_id}&type=${type}&status=${status}&request_status=${request_status}&date_from=${date_from}&date_to=${date_to}`;
                // console.log(url);
                UsersTable.ajax.url(url).load()
            }
        }

        function handleClear() {
            
            $('#employee_id').val('');
            $('#type').val('');
            $('#status').val('');
            
            $('#request_status').val('');
            $('#date_from').val('');
            $('#date_to').val('');
     
            if (UsersTable) {
                var url = "<?php echo e(route('dashboard.requests.data')); ?>";
                UsersTable.ajax.url(url).load()
            }
        }


</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/requests/index.blade.php ENDPATH**/ ?>