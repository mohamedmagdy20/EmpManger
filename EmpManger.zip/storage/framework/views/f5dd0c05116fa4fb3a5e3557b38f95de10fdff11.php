

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="page-title"> <?php echo app('translator')->get('lang.show'); ?> <?php echo e($data->employee->name); ?> <?php echo app('translator')->get('lang.requests'); ?></h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('dashboard.requests.index')); ?>"><?php echo app('translator')->get('lang.requests'); ?></a></li>
        <li class="breadcrumb-item active"><a href="#"><?php echo app('translator')->get('lang.show'); ?> <?php echo app('translator')->get('lang.requests'); ?></a></li>
      </ol>
    </nav>
    
  </div>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <div class="row justify-content-around">
                <h4 class="card-title"><?php echo e($data->employee->name); ?> <?php echo app('translator')->get('lang.requests'); ?></h4>
            </div>
            <div><?php echo $data->description; ?></div>


            <div class="form-group">
                <a href="<?php echo e(route('dashboard.requests.edit',$data->id)); ?>" class="btn btn-primary"><?php echo app('translator')->get('lang.edit'); ?></a>
    
                <a href="<?php echo e(route('dashboard.requests.index')); ?>" class="btn btn-light"><?php echo app('translator')->get('lang.cencel'); ?></a>
            </div>
          </div>
          
        </div>

        
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/requests/show.blade.php ENDPATH**/ ?>