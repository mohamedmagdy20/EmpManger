<ul class="nav" style="position: fixed">
    <li class="nav-item nav-category"></li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
        <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
        <span class="menu-title"><?php echo app('translator')->get('lang.dashboard'); ?></span>
      </a>
    </li>
    <?php if(auth()->user()->hasPermission('show_user')): ?>
    <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
        <span class="icon-bg"><i class="fa fa-user"></i></span>
        <span class="menu-title"><?php echo app('translator')->get('lang.users'); ?></span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="ui-basic">
        <ul class="nav flex-column sub-menu">
          <?php if(auth()->user()->hasPermission('show_user')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('dashboard.users.index')); ?>"><?php echo app('translator')->get('lang.show'); ?> <?php echo app('translator')->get('lang.users'); ?></a></li>
          <?php endif; ?>
          <?php if(auth()->user()->hasPermission('show_role')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('dashboard.roles.index')); ?>"><?php echo app('translator')->get('lang.show'); ?> <?php echo app('translator')->get('lang.role'); ?></a></li>          
          <?php endif; ?>
        </ul>
      </div>
    </li>  
    <?php endif; ?>
    

    <?php if(auth()->user()->hasPermission('show_jobs')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.jobs.index')); ?>">
          <span class="icon-bg"><i class="fa-solid fa-briefcase"></i></span>
          <span class="menu-title"><?php echo app('translator')->get('lang.job'); ?></span>
        </a>
      </li>   
    <?php endif; ?>
   

    <?php if(auth()->user()->hasPermission('show_employees')): ?>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dashboard.employees.index')); ?>?employee">
        <span class="icon-bg"><i class="fa-solid fa-users"></i></span>
        <span class="menu-title"><?php echo app('translator')->get('lang.employees'); ?></span>
      </a>
    </li>
    <?php endif; ?>
  

    <?php if(auth()->user()->hasPermission('show_requests')): ?>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dashboard.requests.index')); ?>">
        <span class="icon-bg"><i class="fa-solid fa-code-pull-request"></i></span>
        <span class="menu-title"><?php echo app('translator')->get('lang.requests'); ?></span>
      </a>
    </li>
    <?php endif; ?>


    
    <?php if(auth()->user()->hasPermission('show_login_history')): ?>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dashboard.login_history.index')); ?>">
        <span class="icon-bg"><i class="fa-solid fa-server"></i></span>
        <span class="menu-title"><?php echo app('translator')->get('lang.login_history'); ?></span>
      </a>
    </li>
    <?php endif; ?>
  
    <li class="nav-item sidebar-user-actions">
      <div class="sidebar-user-menu">
        <form action="<?php echo e(route('logout')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button  class="nav-link border-0"><i class="mdi mdi-logout menu-icon"></i>
            <span class="menu-title text-danger"><?php echo app('translator')->get('lang.logout'); ?></span></button>
        </form>
        </div>
    </li>
  </ul> <?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>