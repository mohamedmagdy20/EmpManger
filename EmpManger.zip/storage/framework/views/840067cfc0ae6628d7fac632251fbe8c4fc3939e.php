

<?php $__env->startSection('content'); ?>

<div class="page-header">
  <h3 class="page-title"> <?php echo app('translator')->get('lang.employees'); ?></h3>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
      <li class="breadcrumb-item active"><a href="<?php echo e(route('dashboard.users.index')); ?>"><?php echo app('translator')->get('lang.employees'); ?></a></li>
   
    </ol>
  </nav>
  
</div>
<div class="col-md-12 grid-margin stretch-card">

<div class="card">
    <div class="card-body">
   
    <div class="row justify-content-between align-items-center">
        <div class="col-md-4">
            <div class="form-group">
                <label for="gender"><?php echo app('translator')->get('lang.gender'); ?></label>
                <select name="gender" class="form-select" id="gender">
                    <option value="<?php echo e(old('gender','male')); ?>"><?php echo app('translator')->get('lang.male'); ?></option>
                    <option value="<?php echo e(old('gender','female')); ?>"><?php echo app('translator')->get('lang.female'); ?></option>
                </select>
            </div>
          
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <label for="status"><?php echo app('translator')->get('lang.status'); ?></label>
                <select name="status" class="form-select" id="status">
                    <option value="<?php echo e(old('status','1')); ?>"><?php echo app('translator')->get('lang.active'); ?></option>
                    <option value="<?php echo e(old('status','0')); ?>"><?php echo app('translator')->get('lang.deactive'); ?></option>
                </select>
            </div>
          
        </div>

        
        <div class="col-md-4">
            <div class="form-group">
                <label for="job_id"><?php echo app('translator')->get('lang.job'); ?></label>
                <select name="job_id" class="form-select" id="job_id">
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(old('job_id',$job->id)); ?>"><?php echo e($job->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
          
        </div>

        
        <div class="col-md-6">
            <div class="form-group">
                <label for="salary_from"><?php echo app('translator')->get('lang.date'); ?></label>
                <input type="date" name="age" class="form-control" id="age">
            </div>
        </div>


        
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="salary_from"><?php echo app('translator')->get('lang.salary_from'); ?></label>
                        <input type="number" name="salary_from" class="form-control" id="salary_from">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="salary_from"><?php echo app('translator')->get('lang.salary_to'); ?></label>
                        <input type="number" name="salary_to" class="form-control" id="salary_to">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 mt-4">
            <div class="d-flex">
                <div class="form-group ">
                    <button class="btn btn-primary" onclick="handleFilter()"><?php echo app('translator')->get('lang.search'); ?> <i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
                <div class="form-group ml-2">
                    <button class="btn " onclick="handleClear()"><?php echo app('translator')->get('lang.clear'); ?></button>
                </div>
            
            </div>
            
        </div>


    

    
    </div>
</div>
        
    </div>
</div>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row justify-content-between align-items-center">
          <div class="col-md-6">
            <h4 class="card-title">Show Employees</h4>
          </div>
          <?php if(auth()->user()->hasPermission('add_employees')): ?>
          <div class="col-md-6">
            <a href="<?php echo e(route('dashboard.employees.create')); ?>" class="btn btn-success"><?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.employees'); ?> <i class="fa fa-plus" style="font-size: 15px;"></i></a>
          </div>
          <?php endif; ?>
        
        </div>

        
        <div class="table-responsive">
            <table class="table table-striped" id="employee-table">
                <thead>
                  <tr>
                    <th> <?php echo app('translator')->get('lang.image'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.link'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.name'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.email'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.phone'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.date_of_birth'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.gender'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.national_id'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.job'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.salary'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.status'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.created_by'); ?> </th>
                    <th> <?php echo app('translator')->get('lang.actions'); ?> </th>
                  </tr>
                </thead>
                <tbody>

                </tbody>
              </table>
           
        </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<script >

let EmployeeTable = null

function setEmployeeDatatable() {
    var url = "<?php echo e(route('dashboard.employees.data')); ?>";
    
    EmployeeTable = $("#employee-table").DataTable({
        processing: true,
        serverSide: true,
        dom: 'Blfrtip',
        lengthMenu: [0, 5, 10, 20, 50, 100, 200, 500],
        pageLength: 9,
        sorting: [0, "DESC"],
        ordering: false,
        ajax: url,
        
        language: {
            paginate: {
                "previous": "<i class='mdi mdi-chevron-left'>",
                "next": "<i class='mdi mdi-chevron-right'>"
            },
        },
        // buttons: [
        //    {
        //                 extend: 'copy',
        //                 className: 'btn btn-light'
        //             },
        //             {
        //                 extend: 'print',
        //                 className: 'btn btn-light'
        //             },
        //             {
        //                 extend: 'pdf',
        //                 className: 'btn btn-light'
        //             },
        //             {
        //                 extend: 'csv',
        //                 className: 'btn btn-light'
        //             },
        // ],
        
        columns: [
            {
                data:'images'
            },
            {
                data:'image_link'
            },
            {
                data:'name'
            },
            {
                data:'email'
            },
            {
                data:'phone'
            },
            {
                data:'age'
            },
            {
                data:'gender'
            },
            {
                data:'national_id'
            },
            {
                data:'job_id'
            },
            {
                data:'salary'
            },
            {
                data:'status'
            },
            {
                data:'created_by'
            },
            {
                data:'actions'
            }
        ],
       
  
    });
}

setEmployeeDatatable();


function deleteConfirmation(id) {
        swal({
            title: "Delete?",
            text: "Please ensure and then confirm!",
            type: "warning",
            showCancelButton: !0,
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel!",
            reverseButtons: !0
        }).then(function (e) {

            if (e.value === true) {
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(url('dashboard/employees/delete')); ?>/" + id,
                    data: {_token: CSRF_TOKEN},
                    dataType: 'JSON',
                    success: function (results) {
                        if(results.status == true)
                        {
                            swal("Done!", results.message, "success");
                            EmployeeTable.ajax.reload()
                        }

                
                    },
                });

            } else {
                e.dismiss;
            }

        }, function (dismiss) {
            return false;
        })
    }


    
    function handleFilter() {
            gender = $('#gender').val() || '';
            age = $('#age').val() || '';
            job = $('#job_id').val() || '';
            status = $('#status').val() || '';
            salary_from = $('#salary_from').val() || '';
            salary_to = $('#salary_to').val() || '';
       
            if (EmployeeTable) {
                var url = "<?php echo e(route('dashboard.employees.data')); ?>" + `?gender=${gender}&age=${age}&status=${status}&job_id=${job}&salary_from=${salary_from}&salary_to=${salary_to}`;
                console.log(url);
                EmployeeTable.ajax.url(url).load()
            }
        }

        function handleClear() {
            $('#gender').val('') ;
            $('#age').val('') ;
            $('#job_id').val('') ;
            $('#status').val('') ;
            $('#salary_from').val('') ;
            $('#salary_to').val('') ;
     
            if (EmployeeTable) {
                var url = "<?php echo e(route('dashboard.employees.data')); ?>";
                EmployeeTable.ajax.url(url).load()
            }
        }

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/employees/index.blade.php ENDPATH**/ ?>