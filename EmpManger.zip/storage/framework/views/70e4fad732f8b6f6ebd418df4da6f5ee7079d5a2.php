

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="page-title"> <?php echo app('translator')->get('lang.edit'); ?> <?php echo app('translator')->get('lang.requests'); ?></h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('dashboard.requests.index')); ?>"><?php echo app('translator')->get('lang.requests'); ?></a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('dashboard.requests.create')); ?>"><?php echo app('translator')->get('lang.edit'); ?> <?php echo app('translator')->get('lang.requests'); ?></a></li>
      </ol>
    </nav>
    
  </div>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title"><?php echo app('translator')->get('lang.edit'); ?> <?php echo app('translator')->get('lang.requests'); ?></h4>
            <form class="forms-sample" method="POST" action="<?php echo e(route('dashboard.requests.update',$data->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <label for="exampleInputemployee1"><?php echo app('translator')->get('lang.employees'); ?></label>
                        <div class="form-group">
                            <select name="employee_id" class="form-select" id="">
                                <?php $__currentLoopData = $emps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>" <?php echo e(old('employee_id', $data->employee_id ?? null) == $d->id ? 'selected' : ''); ?>><?php echo e($d->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="type"><?php echo app('translator')->get('lang.type'); ?></label>
                            <select name="type" class="form-select" id="type">
                                <option value="new" <?php echo e(old('type','new' ?? null) == $data->type ? 'selected' : ''); ?>><?php echo app('translator')->get('lang.new'); ?></option>
                                <option value="rl" <?php echo e(old('type', 'rl' ?? null) == $data->type ? 'selected' : ''); ?>><?php echo app('translator')->get('lang.rl'); ?></option>
                                <option value="da" <?php echo e(old('type','da' ?? null) == $data->type ? 'selected' : ''); ?>><?php echo app('translator')->get('lang.da'); ?></option>
                                <option value="renewal" <?php echo e(old('type', 'renewal' ?? null) == $data->type ? 'selected' : ''); ?>><?php echo app('translator')->get('lang.renewal'); ?></option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="status"><?php echo app('translator')->get('lang.status'); ?></label>

                        <div class="form-group ml-5">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" name="status"   id="flexSwitchCheckChecked" <?php echo e($data->status ? 'selected' : ''); ?>  >
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                       
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="desc"><?php echo app('translator')->get('lang.description'); ?></label>
                            <textarea name="description" class="form-control description" id="description"  cols="30" rows="10"><?php echo $data->description; ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>

                </div>           
              <button type="submit" class="btn btn-primary mr-2"><?php echo app('translator')->get('lang.submit'); ?></button>
              <a href="<?php echo e(route('dashboard.requests.index')); ?>" class="btn btn-light"><?php echo app('translator')->get('lang.cencel'); ?></a>
            </form>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>

<script>
    CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/requests/edit.blade.php ENDPATH**/ ?>