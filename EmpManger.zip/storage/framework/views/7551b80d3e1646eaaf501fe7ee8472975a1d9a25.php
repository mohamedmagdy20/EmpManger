<?php switch($type):
    case ('actions'): ?>
            <?php if(auth()->user()->hasPermission('edit_requests')): ?>
                <a class="btn btn-sm btn-primary" href="<?php echo e(route('dashboard.requests.edit',$data->id)); ?>"><i class="fa fa-pen"></i></a>            
            <?php endif; ?>

            <?php if(auth()->user()->hasPermission('delete_requests')): ?>
              <button class="btn btn-danger btn-flat btn-sm remove-user" data-id="<?php echo e($data->id); ?>" data-action="<?php echo e(route('dashboard.requests.delete',$data->id)); ?>" onclick="deleteConfirmation(<?php echo e($data->id); ?>)"><i class="fa fa-trash"></i></button>
            <?php endif; ?>
            <a class="btn btn-sm btn-warning" href="<?php echo e(route('dashboard.requests.show',$data->id)); ?>"><i class="fa fa-eye"></i></a>
       
    <?php break; ?>
    <?php case ('change-status'): ?>
        <?php if($data->request_status == 'new'): ?>
           <a class="btn btn-primary" onclick="changeStatus(<?php echo e($data->id); ?>,'on_process')">Make On Process</a>
        <?php elseif($data->request_status == 'on_process'): ?>
            <a class="btn btn-light" onclick="changeStatus(<?php echo e($data->id); ?>,'finished')">Finish Request</a>
        <?php else: ?>
            <span class="btn btn-dark">Finished</span>
        <?php endif; ?>
    <?php break; ?>

    <?php case ('status'): ?>
    <?php if($data->status == false): ?>
        <span class="btn btn-sm btn-warning">Deactive</span>
    <?php else: ?>
        <span class="btn btn-sm btn-success">Active</span>
    <?php endif; ?>
<?php break; ?>

    <?php case ('type'): ?>
        
    <?php if($data->type == 'new'): ?>
    
        <span><?php echo app('translator')->get('lang.new'); ?></span> 
    <?php elseif($data->type == 'rl'): ?>
    
       <span><?php echo app('translator')->get('lang.rl'); ?></span> 
    <?php elseif($data->type == 'da'): ?>
    
        <span><?php echo app('translator')->get('lang.da'); ?></span> 
    
    <?php else: ?>
       <span> <?php echo app('translator')->get('lang.renewal'); ?></span> 
    <?php endif; ?>
    <?php break; ?>

    <?php default: ?>     
<?php endswitch; ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/requests/actions.blade.php ENDPATH**/ ?>