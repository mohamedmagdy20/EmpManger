

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="page-title"><?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.users'); ?></h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('dashboard.employees.index')); ?>"><?php echo app('translator')->get('lang.employees'); ?></a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('dashboard.employees.create')); ?>"><?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.employees'); ?></a></li>
      </ol>
    </nav>
    
  </div>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title"><?php echo app('translator')->get('lang.create'); ?> <?php echo app('translator')->get('lang.employees'); ?></h4>
            <form class="forms-sample" method="POST" action="<?php echo e(route('dashboard.employees.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputName1"><?php echo app('translator')->get('lang.name'); ?></label>
                            <input type="text" class="form-control" name="name" id="exampleInputName1" value="<?php echo e(old('name')); ?>" placeholder="<?php echo app('translator')->get('lang.name'); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail3"><?php echo app('translator')->get('lang.email'); ?></label>
                            <input type="email" class="form-control" name="email" id="exampleInputEmail3"  value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('lang.email'); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail3"><?php echo app('translator')->get('lang.phone'); ?></label>
                            <input type="phone" class="form-control" name="phone" id="exampleInputEmail3"  value="<?php echo e(old('phone')); ?>" placeholder="<?php echo app('translator')->get('lang.phone'); ?>">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail3"><?php echo app('translator')->get('lang.date_of_birth'); ?></label>
                            <input type="date" class="form-control" name="age" id="exampleInputEmail3"  value="<?php echo e(old('date')); ?>" placeholder="">
                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>

                    

                    <div class="col-md-6">
                        <label for="status"><?php echo app('translator')->get('lang.status'); ?></label>

                        <div class="form-group ml-5">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" name="status"   id="flexSwitchCheckChecked"  checked>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                       
                    </div>
                    <div class="col-md-12 mb-3">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('lang.image'); ?></label>
                            <input type="file" name="image" id="choose-file" class="form-control">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                           
                          </div>


                          <div id="img-preview"></div>
                
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail3"><?php echo app('translator')->get('lang.job'); ?></label>
                            <select name="job_id" class="form-select" id="">
                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(old('job_id',$job->id)); ?>"><?php echo e($job->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['job_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.salary'); ?></label>
                            <input type="number" class="form-control" name="salary" id="exampleInputPassword4"  value="<?php echo e(old('salary')); ?>" placeholder="<?php echo app('translator')->get('lang.salary'); ?>">
                          </div>
                          <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"> <?php echo e($message); ?> </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.national_id'); ?></label>
                            <input type="number" class="form-control" name="national_id" id="exampleInputPassword4"  value="<?php echo e(old('national_id')); ?>" placeholder="<?php echo app('translator')->get('lang.national_id'); ?>">
                          </div>
                          <?php $__errorArgs = ['national_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                    </div>

                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputPassword4"><?php echo app('translator')->get('lang.gender'); ?></label>
                            <select name="gender" class="form-select" id="">
                                <option value="<?php echo e(old('gender','male')); ?>"><?php echo app('translator')->get('lang.male'); ?></option>
                                <option value="<?php echo e(old('gender','female')); ?>"><?php echo app('translator')->get('lang.female'); ?></option>

                            </select>
                          </div>
                          <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                    </div>

                </div>
              
            
            
              <button type="submit" class="btn btn-primary mr-2"><?php echo app('translator')->get('lang.submit'); ?></button>
              <a href="<?php echo e(route('dashboard.employees.index')); ?>" class="btn btn-light"><?php echo app('translator')->get('lang.cencel'); ?></a>
            </form>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/employees/create.blade.php ENDPATH**/ ?>