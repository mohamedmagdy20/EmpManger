<?php switch($type):
    case ('images'): ?>
    <div class="py-1">
        <img src="<?php echo e($data->image ? asset('uploads/employees/'.$data->image) : asset('assets/images/faces-clipart/pic-1.png')); ?>" class="image-viewer" alt="image" />
    </div>
        <?php break; ?>
    <?php case ('actions'): ?>
    <?php if(auth()->user()->hasPermission('edit_employees')): ?>
        <a class="btn btn-sm btn-primary" href="<?php echo e(route('dashboard.employees.edit',$data->id)); ?>"><i class="fa fa-pen"></i></a>
    <?php endif; ?>
    <?php if(auth()->user()->hasPermission('delete_employees')): ?>
         <button class="btn btn-danger btn-flat btn-sm remove-user" data-id="<?php echo e($data->id); ?>" data-action="<?php echo e(route('dashboard.users.delete',$data->id)); ?>" onclick="deleteConfirmation(<?php echo e($data->id); ?>)"><i class="fa fa-trash"></i></button>
    <?php endif; ?>
      


    <?php break; ?>

    <?php case ('image_link'): ?>
        <a href="<?php echo e($data->image_link); ?>" target="_blank"><i class="fa-solid fa-link"></i></a>
    <?php break; ?>
    <?php case ('status'): ?>
        <?php if($data->status == false): ?>
            <span class="btn btn-sm btn-warning">Deactive</span>
        <?php else: ?>
            <span class="btn btn-sm btn-success">Active</span>
        <?php endif; ?>
    <?php break; ?>
    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/employees/actions.blade.php ENDPATH**/ ?>