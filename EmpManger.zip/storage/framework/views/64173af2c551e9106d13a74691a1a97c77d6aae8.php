

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="page-title"><?php echo app('translator')->get('lang.profile'); ?></h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('lang.dashboard'); ?></a></li>
        <li class="breadcrumb-item active "><a href="<?php echo e(route('dashboard.users.profile.index')); ?>"><?php echo app('translator')->get('lang.profile'); ?></a></li>
      </ol>
    </nav>
    
  </div>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title"><?php echo app('translator')->get('lang.profile'); ?></h4>
            <form class="forms-sample" method="POST" action="<?php echo e(route('dashboard.users.profile.edit-profile')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputName1"><?php echo app('translator')->get('lang.name'); ?></label>
                            <input type="text" class="form-control" name="name" id="exampleInputName1" value="<?php echo e(old('name',auth()->user()->name)); ?>" placeholder="Name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail3"><?php echo app('translator')->get('lang.email'); ?></label>
                            <input type="email" class="form-control" name="email" id="exampleInputEmail3"  value="<?php echo e(old('email',auth()->user()->email)); ?>" placeholder="Email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('lang.image'); ?></label>
                            <input type="file" name="image" id="choose-file" class="form-control">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                           
                          </div>


                          <div id="img-preview"></div>
                          <img class="w-25" src="<?php echo e(asset('uploads/users/'.auth()->user()->image)); ?>" alt="">
                
                    </div>


                </div>
              
            
            
              <button type="submit" class="btn btn-primary mr-2"><?php echo app('translator')->get('lang.submit'); ?></button>
              <a href="<?php echo e(route('dashboard.users.profile.change-password-view')); ?>" class="btn btn-danger"><?php echo app('translator')->get('lang.change-password'); ?></a>
            </form>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/profile/index.blade.php ENDPATH**/ ?>