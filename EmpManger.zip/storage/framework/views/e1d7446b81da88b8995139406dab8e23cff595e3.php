
<?php $__env->startSection('content'); ?>
<div class="row">
  <?php if(auth()->user()->hasPermission('show_reports')): ?>
  <div class="col-xl-4 col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.employees'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($employees); ?></h2>

        <div class="text-center"><i style="font-size: 25px" class="fa fa-users  text-danger"></i></div>
        
      </div>
    </div>
  </div>

  <div class="col-xl-4  col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.users'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($users); ?></h2>
        <div class="text-center"><i style="font-size: 25px" class="fa fa-user  text-success"></i></div>
     
        
        
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.job'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($jobs); ?></h2>
        
        <div class="text-center"><i style="font-size: 25px" class="fa-solid fa-briefcase"></i></div>
    
        
        
      </div>
    </div>
  </div>


  <div class="col-xl-3 col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.new'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($new); ?></h2>

        <div class="text-center"><i style="font-size: 25px" class="fa-solid fa-newspaper text-success"></i></div>
        
      </div>
    </div>
  </div>

  <div class="col-xl-3  col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.rl'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($rl); ?></h2>
        <div class="text-center"><i style="font-size: 25px" class="fa-solid fa-database text-secondary"></i></div>
     
        
        
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.da'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($da); ?></h2>
        
        <div class="text-center"><i style="font-size: 25px" class="fa-solid fa-house-chimney-crack text-danger"></i></div>
    
        
        
      </div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body text-center">
        <h5 class="mb-2 text-dark font-weight-normal"><?php echo app('translator')->get('lang.renewal'); ?></h5>
        <h2 class="mb-4 text-dark font-weight-bold"><?php echo e($renawal); ?></h2>
        
        <div class="text-center"><i style="font-size: 25px" class="fa-solid fa-briefcase"></i></div>
    
        
        
      </div>
    </div>
  </div>

  <div class="col-md-6 grid-margin stretch-card">
    <div class="card">
      
        <canvas id="gender-chart"></canvas>
      
    </div>
  </div>

  <div class="col-md-6 grid-margin stretch-card">
    <div class="card">
      
        <canvas id="request-chart"></canvas>
      
    </div>
  </div>
    
  <?php endif; ?>
  </div>
  
   
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('js'); ?>
<script>
  
const chartData = async () => {
    const response = await fetch('/gender');
    const data = await response.json();
    return data;
};

const renderChart = async () => {
    const data = await chartData();

    const ctx = document.getElementById('gender-chart').getContext('2d');
    // alert(ctx)
    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['<?php echo app('translator')->get('lang.male'); ?>', '<?php echo app('translator')->get('lang.female'); ?>'],
            datasets: [{
                data: [data.male, data.female],
                backgroundColor: ['#3498db', '#e74c3c'],
            }]
        },
        options: {
            responsive: true,
            legend: {
                position: 'bottom',
            },
            title: {
                display: true,
                text: '<?php echo app('translator')->get('lang.gender'); ?>',
            },
            animation: {
                animateScale: true,
                animateRotate: true,
            },
        }
    });
};

const reqeustData = async()=>{
    const response = await fetch('/request-chart');
    const data = await response.json();
    return data; 
}

const requestChart = async () => {
    const data = await reqeustData();

    const ctx = document.getElementById('request-chart').getContext('2d');
    // alert(ctx)
    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['<?php echo app('translator')->get('lang.new'); ?>', '<?php echo app('translator')->get('lang.on_process'); ?>', '<?php echo app('translator')->get('lang.finished'); ?>'],
            datasets: [{
                data: [data.new, data.on_process, data.finish],
                backgroundColor: ['#3498db', '#e74c3c','#333'],
            }]
        },
        options: {
            responsive: true,
            legend: {
                position: 'bottom',
            },
            title: {
                display: true,
                text: '<?php echo app('translator')->get('lang.requests'); ?>',
            },
            animation: {
                animateScale: true,
                animateRotate: true,
            },
        }
    });
};


renderChart();
requestChart();


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/index.blade.php ENDPATH**/ ?>