<?php switch($type):
    case ('image'): ?>
    <div class="py-1">
        <img src="<?php echo e($data->image ? asset('uploads/users/'.$data->image) : asset('assets/images/faces-clipart/pic-1.png')); ?>" class="image-viewer" alt="image" />
    </div>
        <?php break; ?>
    <?php case ('actions'): ?>
    <?php if(auth()->user()->hasPermission('edit_user')): ?>
        <a class="btn btn-sm btn-primary" href="<?php echo e(route('dashboard.users.edit',$data->id)); ?>"><i class="fa fa-pen"></i></a>
    <?php endif; ?>

    <?php if(auth()->user()->hasPermission('delete_user')): ?>
        <button class="btn btn-danger btn-flat btn-sm remove-user" data-id="<?php echo e($data->id); ?>" data-action="<?php echo e(route('dashboard.users.delete',$data->id)); ?>" onclick="deleteConfirmation(<?php echo e($data->id); ?>)"><i class="fa fa-trash"></i></button>    
    <?php endif; ?>
      


        <?php break; ?>
    <?php case ('status'): ?>
        <?php if($data->status == false): ?>
            <span class="btn btn-sm btn-warning"><?php echo app('translator')->get('lang.deactive'); ?></span>
        <?php else: ?>
            <span class="btn btn-sm btn-success"><?php echo app('translator')->get('lang.active'); ?></span>
        <?php endif; ?>
    <?php break; ?>

    <?php case ('roles'): ?>
        <?php $__currentLoopData = $data->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($role->display_name); ?></p> 
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    <?php break; ?>
    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/users/actions.blade.php ENDPATH**/ ?>