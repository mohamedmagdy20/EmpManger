<?php switch($type):
    case ('actions'): ?>
            <?php if(auth()->user()->hasPermission('edit_jobs')): ?>
                <a class="btn btn-sm btn-primary" href="<?php echo e(route('dashboard.jobs.edit',$data->id)); ?>"><i class="fa fa-pen"></i></a>            
            <?php endif; ?>

            <?php if(auth()->user()->hasPermission('delete_jobs')): ?>
              <button class="btn btn-danger btn-flat btn-sm remove-user" data-id="<?php echo e($data->id); ?>" data-action="<?php echo e(route('dashboard.users.delete',$data->id)); ?>" onclick="deleteConfirmation(<?php echo e($data->id); ?>)"><i class="fa fa-trash"></i></button>
            <?php endif; ?>
       
            <?php break; ?>

    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/dashboard/jobs/actions.blade.php ENDPATH**/ ?>