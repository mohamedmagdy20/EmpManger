<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
      <a class="navbar-brand brand-logo" href="index.html"><img src="<?php echo e(asset('assets/images/logo.svg')); ?>" alt="logo" /></a>
      <a class="navbar-brand brand-logo-mini" href="index.html"><img src="<?php echo e(asset('assets/images/logo-mini.svg')); ?>" alt="logo" /></a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-stretch">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="mdi mdi-menu"></span>
      </button>
      
      <ul class="navbar-nav navbar-nav-right">
      
      
        <li class="nav-item nav-language dropdown d-none d-md-block">
          <a class="nav-link dropdown-toggle" id="languageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
            <div class="nav-language-icon">
              <i class="flag-icon flag-icon-us" title="us" id="us"></i>
            </div>
            <div class="nav-language-text">
              <p class="mb-1 text-black"><?php echo app('translator')->get('lang.language'); ?></p>
            </div>
          </a>
          <div class="dropdown-menu navbar-dropdown" aria-labelledby="languageDropdown">
            <a class="dropdown-item" href="<?php echo e(route('change-lang','ar')); ?>">
              <div class="nav-language-icon mr-2">
                <i class="flag-icon flag-icon-ae" title="ae" id="ae"></i>
              </div>
              <div class="nav-language-text">
                <p class="mb-1 text-black"><?php echo app('translator')->get('lang.arabic'); ?></p>
              </div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('change-lang','en')); ?>">
              <div class="nav-language-icon mr-2">
                <i class="flag-icon flag-icon-gb" title="GB" id="gb"></i>
              </div>
              <div class="nav-language-text">
                <p class="mb-1 text-black"><?php echo app('translator')->get('lang.english'); ?></p>
              </div>
            </a>
          </div>
        </li>
        <li class="nav-item nav-profile dropdown">
          <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
            <div class="nav-profile-img">
              <img src="<?php echo e(asset('uploads/users/'.auth()->user()->image)); ?>" alt="image">
            </div>
            <div class="nav-profile-text">
              <p class="mb-1 text-black"><?php echo e(auth()->user()->name); ?></p>
            </div>
          </a>
          <div class="dropdown-menu navbar-dropdown dropdown-menu-right p-0 border-0 font-size-sm" aria-labelledby="profileDropdown" data-x-placement="bottom-end">
            <div class="p-3 text-center bg-primary">
              <img class="img-avatar img-avatar48 img-avatar-thumb" src="<?php echo e(asset('uploads/users/'.auth()->user()->image)); ?>" alt="<?php echo e(auth()->user()->name); ?>">
            </div> 
            <div class="p-2">
              <h5 class="dropdown-header text-uppercase pl-2 text-dark">User Options</h5>
              <a class="dropdown-item py-1 d-flex align-items-center justify-content-between" href="<?php echo e(route('dashboard.users.profile.index')); ?>">
                <span>Profile</span>
                <span class="p-0">
                  
                  <i class="mdi mdi-account-outline ml-1"></i>
                </span>
              </a>
             
              <div role="separator" class="dropdown-divider"></div>
              <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class="dropdown-item py-1 d-flex align-items-center justify-content-between" href="#">
                  <span>Log Out</span>
                  <i class="mdi mdi-logout ml-1"></i>
                </button>
              </form>
             
            </div>
          </div>
        </li>
        
        
      </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="mdi mdi-menu"></span>
      </button>
    </div>
  </nav><?php /**PATH F:\client\EmployeeManger\EmpManger\resources\views/layouts/nav.blade.php ENDPATH**/ ?>