<?php

return [
    'dashboard'=>'Dashboard',

    'project'=>'Employee Mangment System',
    'name'=>'Name',
    'email'=>'Email',
    'password'=>'Password',
    'confirm_password'=>'Confirm Password',
    'description'=>'Descriptions',
    'type'=>'Type',
    'status'=>'Status',
    'job'=>'Jobs',
    'requests'=>'Requests',
    'employees'=>'Employees',
    'users'=>'Users',
    'login_history'=>'Login History',
    'male'=>'Male',
    'phone'=>'Phone',
    'date_of_birth'=>'Date Of Birth',
    'image'=>'Image',
    'salary'=>'Salary',
    'national_id'=>'National ID',
    'submit'=>'Submit',
    'cencel'=>'Cencel',
    'request_type'=>'Request Type',

    'change'=>'change',

    'number_of'=>'Number of',
    'new'=>'New',

    'change-password'=>'Change Password',



    
    'active'=>'Active',
    'deactive'=>'DeActive',
    'created_by'=>'Created By',
    'actions'=>'Actions',


    
    'search'=>'Search',
    'clear'=>'Clear',

    'female'=>'Female',
    'show'=>'Show',
    'create'=>'Add',
    'edit'=>'Edit',
    'delete'=>'Delete',
    'profile'=>'Profile',
    'logout'=>'Logout',
    'gender'=>'Gender',
    'date'=>'Date',
    'date_from'=>'Date From',
    'date_to'=>'Date To',
    'salary_from'=>'Salary From',
    'salary_to'=>'Salary To',
  
    
    'role'=>'Role',
    'permissions'=>'Permissions',
    'rl'=>'Replacement of lost',
    'da'=>'Damaged allowance',
    'renewal'=>'Renewal',
    'on_process'=>'On Process',
    'finished'=>'Finished',    
    'language'=>'Language',
    'english'=>'English',
    'arabic'=>'Arabic'
];